import {Component, OnInit} from '@angular/core';
import {JsonServiceService} from './json-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  sampleData = [];
  textInput = '';
  displayValue: string;

  constructor (private _jsonService: JsonServiceService) {}

  ngOnInit() {
    this._jsonService.getData().subscribe((data) => {
      this.sampleData.push(data);
    });
  }



  onClick(val: string) {
    this.displayValue = val;
  }
}
